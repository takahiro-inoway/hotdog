
//
// ■outer が push つまり新しいインプットボックスを追加するときは
// レンダリングしなおす➤ 付与している id = index と画面上の input の順番が相違するため
//
// ■inner = tag が追加、つまりインプットに文字が入力されて tag が増える場合は
// レンダリングしなおさず、その inner が属する outer の innerText を削除し tag を挿入しなおす
// ➤タグのアウター自体が増えたり移動するわけではないので、全てを更新しなおす必要がない
//

const def_history_style_str = `
<style id="addon_historytag_style">
.addon_historytag {
  user-select: none;
  cursor: pointer;
  color: #296fa8;
  align-items: center;
  border-radius: .375em;
  border: 2px solid #eff5fb;
  display: inline-flex;
  font-size: .75rem;
  height: 2em;
  justify-content: center;
  white-space: nowrap;
}
.addon_historytag_primary, .addon_historytag_delete {
  height: 100%;
  text-align: center;
  line-height: 1.6rem;
  outline: 0;
}
.addon_historytag_primary{
  background-color: #eff5fb;
  padding-left: 0.75em;
  padding-right: 0.75em;
}
.addon_historytag_delete{
  background-color: white;
  width: 16px;
  font-size: .5rem;
  font-weight: bold;
}
</style>
`
// 
// スタイルが存在するかチェックして追加
const def_init_history_style = () => {
  if (document.getElementById("addon_historytag_style") === null || document.getElementById("addon_historytag_style") === undefined) {
    document.getElementsByTagName("head")[0].insertAdjacentHTML("beforeend", def_history_style_str)
  }
}
// 
// 履歴要素追加用のアウター
const def_get_history_outer_str = (id_str) => {
  return `
  <div id="addon_history_outer_${id_str}" data-addon-index="${id_str}" class="addon_history_outer" style="margin: .2em;"></div>
  `
}

//
// インナー要素を返す関数を定義
const def_get_output_inner = (addon_index, text_content, text_index) => {
  return `
    <span class="addon_historytag" data-addon-historytag-event="false">
    <span class="addon_historytag_primary" data-addon-index="${addon_index}" data-addon-historytag-text="${text_content}" data-addon-historytag-index="${text_index}">
    ${text_content}
    </span>
    <span class="addon_historytag_delete" data-addon-index="${addon_index}" data-addon-historytag-text="${text_content}" data-addon-historytag-index="${text_index}">
    ✕
    </span>
    </span>
    `
}
//
// 現在アクセスしているURLがストレージに保存されているか booleanを返す
const def_is_load_site = (options) => {
  if (options.addon_input_history_userdata === undefined) return false
  if (!options.addon_input_history_userdata.some(val => location.host === val.site_host)) return false
  if (!options.addon_input_history_userdata.some(val => location.pathname === val.site_pathname)) return false
  return true
}
//
// 要素挿入用のアウターを全削除➤全挿入
const def_init_outer_insert = (options) => {
  // 今存在している履歴要素追加用のアウターを削除
  Array.from(document.getElementsByClassName("addon_history_outer")).forEach((val, ind) => {
    val.remove()
  })
  // input text と textarea のみ取得
  const inputs = [
    ...Array.from(document.getElementsByTagName("input")).filter((val, ind) => {
      return val.type === "text" || val.type === "search" || val.tagName === "textarea"
    }),
    ...Array.from(document.getElementsByTagName("textarea")),
  ]
  // ユーザーデータをループ➤htmlアウターとユーザーのアウター情報が一致すれば要素を追加
  options.addon_input_history_userdata.forEach((val, ind) => {
    inputs.forEach((input_val, input_ind) => {
      // html が一致しない場合hは処理しない
      let tmp = input_val.cloneNode(true)
      tmp.removeAttribute("data-addon-index")
      if (tmp.outerHTML !== val.input_text_string) return
      // 一致したインプットへの処理
      // 入力時のイベント付与 一旦削除して追加
      input_val.removeEventListener("change", def_add_and_render)
      input_val.addEventListener("change", (e) => { def_add_and_render(e, input_val) }, false)
      // 入力時のイベントに使用するインデックスをデータ属性で付与
      input_val.setAttribute("data-addon-index", ind)
      // input のすぐ後に挿入
      input_val.insertAdjacentHTML("afterend", def_get_history_outer_str(ind))
    })
  })
}// 
// 初期化➤連続追加
const def_init_tag_show = (options) => {
  Array.from(document.getElementsByClassName("addon_history_outer")).forEach((val, ind) => {
    // 一旦消す
    val.innerText = ""
    // 連続追加
    options.addon_input_history_userdata[val.dataset.addonIndex].history_text_list.forEach((text_val, text_ind) => {
      val.insertAdjacentHTML("beforeend", def_get_output_inner(val.dataset.addonIndex, text_val, text_ind))
    })
  })
}
// 初期化➤連続追加
const def_init_target_tag_show = (options, target_ind) => {
  const arr = Array.from(document.getElementsByClassName("addon_history_outer")).forEach((val, ind) => {
    // 処理したい index 以外ならリターン
    if (target_ind !== val.dataset.addonIndex) return
    // 一旦消す
    val.innerText = ""
    // 連続追加
    options.addon_input_history_userdata[val.dataset.addonIndex].history_text_list.forEach((text_val, text_ind) => {
      val.insertAdjacentHTML("beforeend", def_get_output_inner(val.dataset.addonIndex, text_val, text_ind))
    })
  })

}
// 
// タグ全てにイベントを付与する
const def_init_tag_event = (options) => {
  Array.from(document.getElementsByClassName("addon_history_outer")).forEach((val, ind) => {
    Array.from(val.getElementsByClassName("addon_historytag")).forEach((tag_outer, tag_outer_ind) => {
      if (tag_outer.dataset.addonHistorytagEvent === "false") {
        // primary
        tag_outer.children[0].addEventListener("click", (e) => {
          // 文字を挿入する各インプット = textcontetnt
          val.previousElementSibling.value = e.target.dataset.addonHistorytagText
        })

        // delete
        tag_outer.children[1].addEventListener("click", (e) => {
          // 配列から削除
          let tmp = options.addon_input_history_userdata[e.target.dataset.addonIndex].history_text_list
          tmp = tmp.filter((fil_val) => {
            return fil_val !== e.target.dataset.addonHistorytagText
          })
          // 削除した配列を代入
          options.addon_input_history_userdata[e.target.dataset.addonIndex].history_text_list = tmp
          // 保存
          chrome.storage.sync.set(options)
          // 再表示 再イベント付与
          def_init_target_tag_show(options, e.target.dataset.addonIndex)
          def_init_tag_event(options)
        })

        // 重複処理しないようイベント付与済みとして ture にしておく
        val.dataset.addonHistorytagEvent = "true"
      }
    })
  })
}

// 
// 取得 => 保存 => 反映、のイベント定義
const def_add_and_render = (e, input_target) => {
  chrome.storage.sync.get(null, (options) => {
    // 空白の場合は追加しない
    if (input_target.value === "") return
    // 配列にすでに含まれる場合は追加しない
    const arr = options.addon_input_history_userdata[e.target.dataset.addonIndex].history_text_list
    if (arr.indexOf(input_target.value) !== -1) return
    // 配列追加
    options.addon_input_history_userdata[e.target.dataset.addonIndex].history_text_list.push(input_target.value)
    // 保存
    chrome.storage.sync.set(options)
    // 反映 履歴要素連続挿入
    def_init_tag_show(options)
    def_init_tag_event(options)
  })
}


const options_reset = () => {
  console.log("options_reset")
  chrome.storage.sync.clear()
}




