

const popup = () => {
  // ------------------------------------------------------------
  // ボタンイベントの付与
  document.getElementById("start_btn").addEventListener("click", async () => {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: addevent_input_target,
    })
  })
  // ボタンイベントの付与
  document.getElementById("reset_btn").addEventListener("click", async () => {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: options_reset,
    })
  })
  // ボタンイベントの付与
  document.getElementById("get_btn").addEventListener("click", async () => {
    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      function: (e) => {
        chrome.storage.sync.get(null, (test) => {
          console.log(test)
        })
      },
    })
  })

  // 現在拡張機能が ON になっているサイト情報をポップアップ内に表示
  chrome.storage.sync.get(null, (options) => {
    let insert_str = ""
    options.addon_input_history_userdata.forEach((val, ind) => {
      insert_str += `
      <tr><td>
      URL<span class="tag is-small m_02">${val.site_host}${val.site_pathname}</span>
      <br>
      入力<span class="tag is-small m_02">${val.placeholder}</span>
      </td></tr>
      `
    })
    document.getElementById("site_detail_tbody").insertAdjacentHTML("beforeend", insert_str)
  })

  // ------------------------------------------------------------

  const addevent_input_target = () => {
    // input text と textarea のみ取得
    const inputs = [
      ...Array.from(document.getElementsByTagName("input")).filter((val, ind) => {
        return val.type === "text" || val.type === "search" || val.tagName === "textarea"
      }),
      ...Array.from(document.getElementsByTagName("textarea")),
    ]
    // input text が1つもなければリターン
    if (inputs === null) {
      alert("有効な入力箇所がありませんでした。")
      return
    }
    if (inputs.length === 0) {
      alert("有効な入力箇所がありませんでした。")
      return
    }
    // スタイルを付与しておく
    def_init_history_style()
    // target をストレージに格納しつつ、イベント削除、スタイル戻し を行う
    const set_target = (e) => {
      // 取得 追加 保存
      chrome.storage.sync.get(null, (options) => {
        if (options.addon_input_history_userdata === undefined) {
          options = {
            addon_input_history_userdata: []
          }
        }
        // 入力時のイベントに使用するインデックスをデータ属性で付与
        options.addon_input_history_userdata.push(
          {
            input_tagname: e.target.tagName,
            input_text_string: e.target.outerHTML,
            history_text_list: [],
            site_host: location.host,
            site_pathname: location.pathname,
            placeholder: e.target.getAttribute("placeholder")
          }
        )
        chrome.storage.sync.set(options)

        // 履歴要素追加用のアウター全削除・全挿入
        def_init_outer_insert(options)
        // 履歴要素連続挿入
        if (options.addon_input_history_userdata.length !== 0) {
          def_init_tag_show(options)
          def_init_tag_event(options)
        }

        // 全ての input text のクリックイベントを削除
        inputs.forEach((val, ind) => {
          val.removeEventListener("click", set_target)
        })

      })
    }
    //
    // 全ての input text にイベントを付与、他をする
    inputs.forEach((val, ind) => {
      // イベントを付与
      val.addEventListener("click", set_target, false)
    })
  }
}

window.onload = () => {
  // 実行
  popup()
}
