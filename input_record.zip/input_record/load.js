



// ------------------------------------------------------------
// 保存されている要素を取得する
chrome.storage.sync.get(null, (options) => {

  // 
  // 処理判定 ======
  // ストレージに保存している対象のサイトではない場合リターン
  // host, pathname に一つでも一致があれば true
  if(!def_is_load_site(options)) return

  // 
  // 初期化 ======
  // 
  // スタイルを付与しておく =======
  def_init_history_style()

  // 履歴要素追加用のアウター挿入
  def_init_outer_insert(options)
  // 履歴要素連続挿入
  if (options.addon_input_history_userdata.length !== 0) {
    def_init_tag_show(options)
    def_init_tag_event(options)
  }


});









